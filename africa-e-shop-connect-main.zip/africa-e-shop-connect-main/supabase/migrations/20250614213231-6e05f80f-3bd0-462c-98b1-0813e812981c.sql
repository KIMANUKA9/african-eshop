
-- First, sign up a user normally through your app, then update their profile to admin
-- Replace 'your-admin-email@example.com' with the actual email you used to sign up
UPDATE public.profiles 
SET user_type = 'admin', is_approved = true 
WHERE email = 'your-admin-email@example.com';
