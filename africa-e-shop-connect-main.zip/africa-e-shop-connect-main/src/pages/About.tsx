
import Header from '@/components/Header';
import { useAuth } from '@/hooks/useAuth';
import { Shield, Users, Globe, Award } from 'lucide-react';

const About = () => {
  const { profile } = useAuth();

  return (
    <div>
      <Header userType={profile?.user_type} />
      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About Africa E-Shop Connect</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Connecting buyers and sellers across Tanzania through a secure, reliable, and user-friendly e-commerce platform.
          </p>
        </div>

        {/* Mission Section */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
            <p className="text-gray-600 mb-4">
              To empower Tanzanian entrepreneurs and businesses by providing them with a modern, 
              accessible platform to reach customers nationwide. We believe in the power of local 
              commerce and aim to bridge the gap between traditional markets and digital innovation.
            </p>
            <p className="text-gray-600">
              Our platform supports local payment methods like M-Pesa, Tigo Pesa, and Halotel, 
              making it easy for everyone to participate in the digital economy.
            </p>
          </div>
          <div className="bg-gradient-to-br from-orange-400 to-red-500 rounded-2xl p-8">
            <img 
              src="/lovable-uploads/1f564883-4221-43d4-a026-4f608f3ddadc.png" 
              alt="Mission" 
              className="w-full h-auto rounded-lg"
            />
          </div>
        </div>

        {/* Values Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Our Values</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Trust & Security</h3>
              <p className="text-gray-600">
                We prioritize the security of transactions and personal data with robust protection measures.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Community</h3>
              <p className="text-gray-600">
                Building a strong community of buyers and sellers who support each other's growth.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Accessibility</h3>
              <p className="text-gray-600">
                Making e-commerce accessible to everyone, regardless of their technical background.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Excellence</h3>
              <p className="text-gray-600">
                Committed to providing the best possible experience for all our users.
              </p>
            </div>
          </div>
        </div>

        {/* Team Section */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Impact</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div>
              <div className="text-3xl font-bold text-orange-500 mb-2">1000+</div>
              <p className="text-gray-600">Active Sellers</p>
            </div>
            <div>
              <div className="text-3xl font-bold text-orange-500 mb-2">10,000+</div>
              <p className="text-gray-600">Happy Customers</p>
            </div>
            <div>
              <div className="text-3xl font-bold text-orange-500 mb-2">50,000+</div>
              <p className="text-gray-600">Products Listed</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
