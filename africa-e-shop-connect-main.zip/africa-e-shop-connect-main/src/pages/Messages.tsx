
import MessagesPage from '@/components/messaging/MessagesPage';

const Messages = () => {
  return <MessagesPage />;
};

export default Messages;
