
import MarketplacePage from '@/components/MarketplacePage';
import { useAuth } from '@/hooks/useAuth';

const Marketplace = () => {
  const { profile } = useAuth();
  return <MarketplacePage userType={profile?.user_type || 'buyer'} />;
};

export default Marketplace;
