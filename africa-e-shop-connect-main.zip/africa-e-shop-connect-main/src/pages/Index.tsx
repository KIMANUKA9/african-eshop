
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Search, ShoppingBag, Store, Truck, Shield, Star, ArrowRight, Sparkles } from 'lucide-react';
import AuthModal from '@/components/auth/AuthModal';
import { useAuth } from '@/hooks/useAuth';
import Header from '@/components/Header';
import AdminDashboard from '@/components/AdminDashboard';
import MarketplacePage from '@/components/MarketplacePage';
import { PaymentMethods } from '@/components/ui/payment-methods';

const Index = () => {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const { user, profile, loading: authLoading } = useAuth();

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-orange-50">
        <div className="text-center">
          <div className="w-20 h-20 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse shadow-xl">
            <ShoppingBag className="w-10 h-10 text-white" />
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-orange-500 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-red-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
          </div>
          <p className="text-gray-600 mt-4 font-medium">Loading your marketplace...</p>
        </div>
      </div>
    );
  }

  // Show admin dashboard for admin users
  if (user && profile?.user_type === 'admin') {
    return (
      <div>
        <Header userType="admin" />
        <AdminDashboard />
      </div>
    );
  }

  // Show marketplace for authenticated users (buyers/sellers)
  if (user && profile) {
    return <MarketplacePage userType={profile.user_type} />;
  }

  const handleLogin = () => {
    setAuthMode('signin');
    setShowAuthModal(true);
  };

  const handleRegister = () => {
    setAuthMode('signup');
    setShowAuthModal(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-orange-50">
      {/* Modern Header */}
      <header className="bg-white/95 backdrop-blur-sm shadow-lg border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Modern Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-xl">A</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                  Africa E-Shop
                </h1>
                <p className="text-xs text-gray-500 font-medium">Connect</p>
              </div>
            </div>

            {/* Enhanced Search Bar */}
            <div className="hidden md:flex flex-1 max-w-2xl mx-8">
              <div className="relative w-full group">
                <input
                  type="text"
                  placeholder="Search for amazing products..."
                  className="w-full px-6 py-3 pl-12 pr-24 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-300 group-hover:border-gray-300 shadow-sm"
                />
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Button className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 px-6 shadow-md">
                  Search
                </Button>
              </div>
            </div>

            {/* Modern Navigation */}
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                onClick={handleLogin}
                className="flex items-center space-x-2 hover:bg-orange-50 text-gray-700 font-medium"
              >
                <span>Login</span>
              </Button>
              <Button 
                onClick={handleRegister}
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 shadow-lg text-white font-medium"
              >
                Get Started
              </Button>
              <Button 
                variant="outline"
                className="hidden lg:flex items-center space-x-2 border-2 hover:bg-gray-50"
              >
                <Store className="w-4 h-4" />
                <span>Sell Now</span>
              </Button>
              <div className="relative">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center shadow-md">
                  <ShoppingBag className="w-5 h-5 text-white" />
                </div>
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold shadow-md">
                  0
                </span>
              </div>
            </div>
          </div>

          {/* Mobile Search */}
          <div className="md:hidden mt-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search products..."
                className="w-full px-4 py-3 pl-10 pr-20 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Button className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-orange-500 to-red-500 text-sm px-4">
                Search
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Modern Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          {/* Enhanced Hero Content */}
          <div className="space-y-8">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-orange-100 to-red-100 text-orange-700 px-6 py-3 rounded-full text-sm font-bold shadow-md">
              <Sparkles className="w-4 h-4" />
              <span>Tanzania's Premier Marketplace</span>
            </div>
            
            <div className="space-y-6">
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Discover <span className="bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">Amazing</span><br />
                Products Online
              </h1>
              
              <p className="text-xl text-gray-600 leading-relaxed">
                Shop unique products from talented Tanzanian sellers. Pay securely with trusted methods and get fast delivery across the country.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-10 py-4 rounded-xl flex items-center space-x-3 shadow-xl text-lg font-bold"
                onClick={handleRegister}
              >
                <ShoppingBag className="w-6 h-6" />
                <span>Start Shopping</span>
                <ArrowRight className="w-5 h-5" />
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-2 border-gray-300 text-gray-700 hover:bg-gray-50 px-10 py-4 rounded-xl flex items-center space-x-3 text-lg font-bold"
                onClick={handleRegister}
              >
                <Store className="w-6 h-6" />
                <span>Become a Seller</span>
              </Button>
            </div>

            {/* Enhanced Payment Methods */}
            <div className="pt-8">
              <p className="text-sm text-gray-500 mb-6 font-medium">Trusted payment methods across Tanzania</p>
              <PaymentMethods />
            </div>
          </div>

          {/* Enhanced Hero Visual */}
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-orange-400 to-red-500 rounded-3xl transform rotate-3 opacity-10"></div>
            <div className="relative bg-gradient-to-br from-orange-400 to-red-500 rounded-3xl p-8 shadow-2xl overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/20 rounded-full -mr-16 -mt-16"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/20 rounded-full -ml-12 -mb-12"></div>
              
              <img 
                src="/lovable-uploads/1f564883-4221-43d4-a026-4f608f3ddadc.png" 
                alt="Sale Banner" 
                className="w-full h-auto rounded-2xl shadow-xl relative z-10"
              />
              
              <div className="absolute bottom-6 left-6 bg-white/95 backdrop-blur-sm rounded-xl px-6 py-3 shadow-lg">
                <div className="flex items-center space-x-3">
                  <Star className="w-5 h-5 text-yellow-500 fill-current" />
                  <span className="text-sm font-bold text-gray-800">Verified Seller</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Features Section */}
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          {[
            {
              icon: Shield,
              title: "Secure Payments",
              description: "Pay safely with M-Pesa, Halotel, Mixx by yas and other trusted payment methods",
              color: "blue"
            },
            {
              icon: Truck,
              title: "Fast Delivery",
              description: "Get your orders delivered quickly to your doorstep across Tanzania",
              color: "green"
            },
            {
              icon: Store,
              title: "Local Sellers",
              description: "Support local businesses and discover unique products from Tanzanian entrepreneurs",
              color: "purple"
            }
          ].map((feature, index) => (
            <div key={index} className="group text-center p-8 bg-white rounded-2xl shadow-lg border hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
              <div className={`w-20 h-20 bg-${feature.color}-100 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className={`w-10 h-10 text-${feature.color}-600`} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Modern CTA Section */}
        <div className="text-center bg-gradient-to-r from-gray-900 to-gray-800 rounded-3xl p-16 text-white relative overflow-hidden">
          <div 
            className="absolute inset-0 opacity-50"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Ccircle cx='30' cy='30' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
            }}
          ></div>
          <div className="relative">
            <h2 className="text-4xl font-bold mb-6">Ready to Start Your Journey?</h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Join thousands of satisfied customers and sellers on Tanzania's most trusted marketplace
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 px-10 py-4 text-lg font-bold"
                onClick={handleRegister}
              >
                Join Now - It's Free!
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Auth Modals */}
      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)}
        defaultMode={authMode}
      />
    </div>
  );
};

export default Index;
