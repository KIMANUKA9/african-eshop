
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface Product {
  id: string;
  shop_id: string;
  category_id: string | null;
  name: string;
  description: string | null;
  price: number;
  stock: number;
  image_url: string | null;
  images: string[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
  location_name: string | null;
  location_address: string | null;
  location_coordinates: any | null;
  shops?: {
    name: string;
    seller_id: string;
  };
  categories?: {
    name: string;
  };
}

export const useProducts = () => {
  return useQuery({
    queryKey: ['products'],
    queryFn: async () => {
      console.log('Fetching all products...');
      
      const { data, error } = await supabase
        .from('products')
        .select(`
          *,
          shops(name, seller_id),
          categories(name)
        `)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching products:', error);
        throw error;
      }
      
      console.log('Products fetched successfully:', data?.length || 0);
      return data as Product[];
    },
    retry: 3,
    retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
};

export const useProductsByCategory = (categoryId: string | null) => {
  return useQuery({
    queryKey: ['products', 'category', categoryId],
    queryFn: async () => {
      console.log('Fetching products by category:', categoryId);
      
      let query = supabase
        .from('products')
        .select(`
          *,
          shops(name, seller_id),
          categories(name)
        `)
        .eq('is_active', true);

      if (categoryId) {
        query = query.eq('category_id', categoryId);
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching products by category:', error);
        throw error;
      }
      
      console.log('Products by category fetched successfully:', data?.length || 0);
      return data as Product[];
    },
    enabled: categoryId !== undefined,
    retry: 3,
    retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
};

export const useAddToCart = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ productId, quantity = 1 }: { productId: string; quantity?: number }) => {
      const { data: existingItem } = await supabase
        .from('cart')
        .select('*')
        .eq('product_id', productId)
        .eq('user_id', (await supabase.auth.getUser()).data.user?.id)
        .single();

      if (existingItem) {
        const { error } = await supabase
          .from('cart')
          .update({ quantity: existingItem.quantity + quantity })
          .eq('id', existingItem.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('cart')
          .insert({
            product_id: productId,
            quantity,
            user_id: (await supabase.auth.getUser()).data.user?.id,
          });

        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cart'] });
    },
  });
};
