
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export const usePendingSellers = () => {
  return useQuery({
    queryKey: ['pending-sellers'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_type', 'seller')
        .eq('is_approved', false)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    },
  });
};

export const useApproveSeller = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (sellerId: string) => {
      const { error } = await supabase
        .from('profiles')
        .update({ is_approved: true })
        .eq('id', sellerId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-sellers'] });
      toast({
        title: 'Seller Approved',
        description: 'The seller has been successfully approved.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to approve seller. Please try again.',
        variant: 'destructive',
      });
    },
  });
};

export const useRejectSeller = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (sellerId: string) => {
      const { error } = await supabase
        .from('profiles')
        .delete()
        .eq('id', sellerId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-sellers'] });
      toast({
        title: 'Seller Rejected',
        description: 'The seller application has been rejected.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to reject seller. Please try again.',
        variant: 'destructive',
      });
    },
  });
};
