import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

export interface SellerProduct {
  id: string;
  name: string;
  description: string | null;
  price: number;
  stock: number;
  image_url: string | null;
  images: string[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
  category_id: string | null;
  location_name: string | null;
  location_address: string | null;
  location_coordinates: any | null;
  categories?: {
    name: string;
  };
}

export const useSellerProducts = () => {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['seller-products', user?.id],
    queryFn: async () => {
      if (!user) throw new Error('User not authenticated');

      // First get the seller's shop
      const { data: shop, error: shopError } = await supabase
        .from('shops')
        .select('id')
        .eq('seller_id', user.id)
        .maybeSingle();

      if (shopError) {
        console.error('Error fetching shop:', shopError);
        throw shopError;
      }

      if (!shop) {
        console.log('No shop found for seller, returning empty array');
        return [];
      }

      // Then get products for that shop
      const { data, error } = await supabase
        .from('products')
        .select(`
          *,
          categories(name)
        `)
        .eq('shop_id', shop.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching products:', error);
        throw error;
      }
      
      console.log('Products loaded successfully:', data?.length || 0);
      return data as SellerProduct[];
    },
    enabled: !!user,
    retry: 3,
    retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
};

export const useCreateProduct = () => {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (productData: {
      name: string;
      description: string;
      price: number;
      stock: number;
      category_id: string;
      location_name?: string;
      location_address?: string;
      images: File[];
    }) => {
      if (!user) throw new Error('User not authenticated');

      // Get or create seller's shop
      let { data: shop, error: shopError } = await supabase
        .from('shops')
        .select('id, name')
        .eq('seller_id', user.id)
        .maybeSingle();

      if (shopError) {
        console.error('Error fetching shop:', shopError);
        throw shopError;
      }

      // If no shop exists, create one
      if (!shop) {
        console.log('No shop found, creating one for seller...');
        
        // Get user profile for shop name
        const { data: profile } = await supabase
          .from('profiles')
          .select('full_name')
          .eq('id', user.id)
          .single();

        const shopName = profile?.full_name ? `${profile.full_name}'s Shop` : 'My Shop';

        const { data: newShop, error: createShopError } = await supabase
          .from('shops')
          .insert({
            seller_id: user.id,
            name: shopName,
            is_active: true,
          })
          .select('id, name')
          .single();

        if (createShopError) {
          console.error('Error creating shop:', createShopError);
          throw new Error('Failed to create shop for seller');
        }

        shop = newShop;
        console.log('Shop created successfully:', shop);
      }

      // Process images and create better placeholder URLs
      let imageUrls: string[] = [];
      let primaryImageUrl: string | null = null;

      if (productData.images.length > 0) {
        console.log('Processing images...');
        
        for (let i = 0; i < productData.images.length; i++) {
          const file = productData.images[i];
          console.log(`Processing image ${i + 1}/${productData.images.length}:`, file.name, file.type);

          // Create a more realistic placeholder URL using a public image service
          // These URLs will actually load and display images
          const placeholderUrls = [
            'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&h=300&fit=crop',
            'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=300&fit=crop',
            'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&h=300&fit=crop',
            'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&h=300&fit=crop',
            'https://images.unsplash.com/photo-1542736667-069246bdbc6d?w=400&h=300&fit=crop'
          ];
          
          const placeholderUrl = placeholderUrls[i % placeholderUrls.length];
          imageUrls.push(placeholderUrl);
          
          if (i === 0) {
            primaryImageUrl = placeholderUrl;
          }
        }
      }

      console.log('Creating product with data:', {
        shop_id: shop.id,
        name: productData.name,
        description: productData.description,
        price: productData.price,
        stock: productData.stock,
        category_id: productData.category_id,
        location_name: productData.location_name || null,
        location_address: productData.location_address || null,
        image_url: primaryImageUrl,
        images: imageUrls,
        is_active: true,
      });

      // Create the product
      const { data: product, error } = await supabase
        .from('products')
        .insert({
          shop_id: shop.id,
          name: productData.name,
          description: productData.description,
          price: productData.price,
          stock: productData.stock,
          category_id: productData.category_id,
          location_name: productData.location_name || null,
          location_address: productData.location_address || null,
          image_url: primaryImageUrl,
          images: imageUrls,
          is_active: true,
        })
        .select()
        .single();

      if (error) {
        console.error('Error creating product:', error);
        throw error;
      }

      console.log('Product created successfully:', product);
      return product;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['seller-products'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      toast({
        title: 'Product Created!',
        description: 'Your product has been successfully added with sample images.',
      });
    },
    onError: (error) => {
      console.error('Product creation failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      toast({
        title: 'Error',
        description: `Failed to create product: ${errorMessage}`,
        variant: 'destructive',
      });
    },
  });
};

export const useUpdateProduct = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ productId, productData }: {
      productId: string;
      productData: {
        name: string;
        description: string;
        price: number;
        stock: number;
        category_id: string;
        location_name?: string;
        location_address?: string;
        is_active: boolean;
        images?: string[];
        image_url?: string | null;
      };
    }) => {
      console.log('Updating product:', productId, productData);

      const updateData: any = {
        name: productData.name,
        description: productData.description,
        price: productData.price,
        stock: productData.stock,
        category_id: productData.category_id,
        location_name: productData.location_name || null,
        location_address: productData.location_address || null,
        is_active: productData.is_active,
        updated_at: new Date().toISOString(),
      };

      // Include image updates if provided
      if (productData.images !== undefined) {
        updateData.images = productData.images;
      }
      if (productData.image_url !== undefined) {
        updateData.image_url = productData.image_url;
      }

      const { data: product, error } = await supabase
        .from('products')
        .update(updateData)
        .eq('id', productId)
        .select()
        .single();

      if (error) {
        console.error('Error updating product:', error);
        throw error;
      }

      console.log('Product updated successfully:', product);
      return product;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['seller-products'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      toast({
        title: 'Product Updated!',
        description: 'Your product has been successfully updated.',
      });
    },
    onError: (error) => {
      console.error('Product update failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      toast({
        title: 'Error',
        description: `Failed to update product: ${errorMessage}`,
        variant: 'destructive',
      });
    },
  });
};

export const useDeleteProduct = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (productId: string) => {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', productId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['seller-products'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      toast({
        title: 'Product Deleted',
        description: 'Product has been successfully deleted.',
      });
    },
    onError: (error) => {
      console.error('Product deletion failed:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete product. Please try again.',
        variant: 'destructive',
      });
    },
  });
};
