
import { useState } from 'react';
import { useParams } from 'react-router-dom';
import Header from '@/components/Header';
import LogisticsInfo from '@/components/logistics/LogisticsInfo';
import ChatWindow from '@/components/messaging/ChatWindow';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ShoppingCart, MessageCircle, Heart } from 'lucide-react';
import { useProducts, useAddToCart } from '@/hooks/useProducts';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { useCreateConversation } from '@/hooks/useMessages';
import ProductImage from '@/components/common/ProductImage';

const ProductDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const { data: products = [] } = useProducts();
  const { user, profile } = useAuth();
  const addToCart = useAddToCart();
  const createConversation = useCreateConversation();
  const { toast } = useToast();
  const [showChat, setShowChat] = useState(false);
  const [conversationId, setConversationId] = useState<string>('');

  const product = products.find(p => p.id === id);

  if (!product) {
    return (
      <div>
        <Header userType={profile?.user_type} />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-800">Product not found</h1>
          </div>
        </div>
      </div>
    );
  }

  const handleAddToCart = async () => {
    if (!user) {
      toast({
        title: 'Login Required',
        description: 'Please login to add items to cart',
        variant: 'destructive',
      });
      return;
    }

    try {
      await addToCart.mutateAsync({ productId: product.id });
      toast({
        title: 'Added to Cart',
        description: `${product.name} has been added to your cart`,
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to add item to cart',
        variant: 'destructive',
      });
    }
  };

  const handleContactSeller = async () => {
    if (!user) {
      toast({
        title: 'Login Required',
        description: 'Please login to contact sellers',
        variant: 'destructive',
      });
      return;
    }

    try {
      const conversation = await createConversation.mutateAsync({
        sellerId: product.shops?.seller_id || 'seller',
        productId: product.id,
      });
      setConversationId(conversation.id);
      setShowChat(true);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to start conversation',
        variant: 'destructive',
      });
    }
  };

  return (
    <div>
      <Header userType={profile?.user_type} />
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Product Images */}
          <div>
            <ProductImage
              src={product.image_url || ''}
              alt={product.name}
              className="w-full h-96 object-cover rounded-lg"
            />
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">{product.name}</h1>
              <p className="text-gray-600 mt-2">{product.description}</p>
              
              <div className="flex items-center space-x-4 mt-4">
                <span className="text-3xl font-bold text-blue-600">
                  TSh {product.price.toLocaleString()}
                </span>
                <Badge variant="outline">
                  {product.categories?.name || 'Uncategorized'}
                </Badge>
              </div>

              <div className="mt-4">
                <p className="text-sm text-gray-600">
                  Sold by: <span className="font-medium">{product.shops?.name}</span>
                </p>
                <p className="text-sm text-gray-600">
                  Stock: <span className="font-medium">{product.stock} units available</span>
                </p>
                {product.location_name && (
                  <p className="text-sm text-gray-600">
                    Location: <span className="font-medium">{product.location_name}</span>
                  </p>
                )}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button 
                className="w-full" 
                onClick={handleAddToCart}
                disabled={product.stock === 0 || addToCart.isPending}
              >
                <ShoppingCart className="w-4 h-4 mr-2" />
                {addToCart.isPending ? 'Adding...' : 'Add to Cart'}
              </Button>
              
              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" onClick={handleContactSeller}>
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Contact Seller
                </Button>
                <Button variant="outline">
                  <Heart className="w-4 h-4 mr-2" />
                  Save
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs for Additional Info */}
        <div className="mt-12">
          <Tabs defaultValue="logistics" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="logistics">Delivery & Location</TabsTrigger>
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>
            
            <TabsContent value="logistics" className="mt-6">
              <LogisticsInfo product={product} />
            </TabsContent>
            
            <TabsContent value="description" className="mt-6">
              <div className="bg-white rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-4">Product Description</h3>
                <p className="text-gray-700 leading-relaxed">
                  {product.description || 'No detailed description available for this product.'}
                </p>
              </div>
            </TabsContent>
            
            <TabsContent value="reviews" className="mt-6">
              <div className="bg-white rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-4">Customer Reviews</h3>
                <p className="text-gray-500">No reviews yet. Be the first to review this product!</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Chat Modal */}
        {showChat && conversationId && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-2xl mx-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Chat with Seller</h3>
                <Button variant="outline" onClick={() => setShowChat(false)}>
                  Close
                </Button>
              </div>
              <ChatWindow
                conversationId={conversationId}
                recipientId={product.shops?.seller_id || 'seller'}
                recipientName={product.shops?.name || 'Seller'}
                onBack={() => setShowChat(false)}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetailPage;
