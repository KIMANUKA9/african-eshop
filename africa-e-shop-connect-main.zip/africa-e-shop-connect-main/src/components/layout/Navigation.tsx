
import { cn } from '@/lib/utils';
import { MessageCircle } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

interface NavigationProps {
  className?: string;
}

const Navigation = ({ className }: NavigationProps) => {
  const location = useLocation();

  const getLinkClass = (path: string) => {
    return location.pathname === path 
      ? "text-orange-600 font-medium border-b-2 border-orange-600 pb-1" 
      : "text-gray-700 hover:text-orange-600 transition-colors hover:border-b-2 hover:border-orange-300 pb-1";
  };

  return (
    <nav className={cn(className)}>
      <Link to="/" className={getLinkClass('/')}>
        Home
      </Link>
      <Link to="/marketplace" className={getLinkClass('/marketplace')}>
        Marketplace
      </Link>
      <Link to="/messages" className={`${getLinkClass('/messages')} flex items-center space-x-1`}>
        <MessageCircle className="w-4 h-4" />
        <span>Messages</span>
      </Link>
      <Link to="/about" className={getLinkClass('/about')}>
        About
      </Link>
      <Link to="/contact" className={getLinkClass('/contact')}>
        Contact
      </Link>
    </nav>
  );
};

export default Navigation;
