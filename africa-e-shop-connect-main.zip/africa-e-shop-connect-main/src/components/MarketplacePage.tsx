
import { useState } from 'react';
import Header from '@/components/Header';
import ProductCard from '@/components/ProductCard';
import SellerDashboard from '@/components/seller/SellerDashboard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Filter, Sparkles, TrendingUp, Star } from 'lucide-react';
import { useProducts } from '@/hooks/useProducts';
import { useCategories } from '@/hooks/useCategories';
import { PaymentMethods } from '@/components/ui/payment-methods';

interface MarketplacePageProps {
  userType: 'admin' | 'seller' | 'buyer';
}

const MarketplacePage = ({ userType }: MarketplacePageProps) => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  const { data: products = [], isLoading: productsLoading } = useProducts();
  const { data: categories = [] } = useCategories();

  const filteredProducts = products.filter(product => {
    const matchesSearch = !searchQuery || 
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = !selectedCategory || product.category_id === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  // If user is a seller, show the seller dashboard directly without the marketplace view
  if (userType === 'seller') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-red-50">
        <Header userType="seller" />
        <SellerDashboard />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-red-50">
      <Header userType={userType} />
      <div className="container mx-auto px-4 py-8">
        {/* Enhanced Hero Section */}
        <div className="bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 text-white rounded-3xl p-12 mb-12 relative overflow-hidden shadow-2xl">
          <div 
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
            }}
          ></div>
          <div className="relative max-w-4xl">
            <div className="flex items-center space-x-3 mb-6">
              <Sparkles className="w-8 h-8 text-yellow-300" />
              <span className="text-xl font-bold">Welcome to Tanzania's Best Marketplace</span>
            </div>
            <h1 className="text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Shop Amazing<br />
              <span className="text-yellow-300">Local Products</span>
            </h1>
            <p className="text-xl lg:text-2xl mb-8 text-orange-100 max-w-2xl leading-relaxed">
              Discover unique products from talented sellers across Tanzania. 
              Shop with confidence using secure payment methods.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 items-start">
              <Button 
                variant="secondary" 
                size="lg"
                className="bg-white text-orange-600 hover:bg-orange-50 font-bold px-8 py-4 text-lg shadow-lg border-2 border-white"
              >
                <TrendingUp className="w-5 h-5 mr-2" />
                Explore Trending
              </Button>
              <PaymentMethods className="mt-4 sm:mt-0" />
            </div>
          </div>
          <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-white/10 rounded-full"></div>
          <div className="absolute -top-5 -right-5 w-20 h-20 bg-yellow-300/20 rounded-full"></div>
        </div>

        {/* Enhanced Search and Filter */}
        <div className="bg-white rounded-2xl shadow-xl p-6 mb-10 border border-orange-100">
          <div className="flex flex-col lg:flex-row gap-4 items-center">
            <div className="flex-1 relative group">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-orange-400 w-5 h-5 group-hover:text-orange-600 transition-colors" />
              <Input 
                placeholder="Search for amazing products..." 
                className="pl-12 py-4 text-lg border-2 border-orange-200 focus:border-orange-500 rounded-xl bg-orange-50/30 focus:bg-white transition-colors"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button 
              variant="outline"
              className="border-2 border-orange-200 hover:border-orange-300 hover:bg-orange-50 px-6 py-4 text-orange-700"
            >
              <Filter className="w-5 h-5 mr-2" />
              Advanced Filters
            </Button>
          </div>
        </div>

        {/* Enhanced Categories */}
        <div className="mb-12">
          <div className="flex items-center space-x-3 mb-6">
            <Star className="w-6 h-6 text-orange-500" />
            <h2 className="text-3xl font-bold text-gray-900">Shop by Category</h2>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button 
              variant={selectedCategory === null ? "default" : "outline"}
              onClick={() => setSelectedCategory(null)}
              className={selectedCategory === null 
                ? "bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg hover:from-orange-600 hover:to-red-600" 
                : "border-2 border-orange-200 hover:border-orange-300 hover:bg-orange-50 text-orange-700"
              }
            >
              All Categories
            </Button>
            {categories.map((category) => (
              <Button 
                key={category.id} 
                variant={selectedCategory === category.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.id)}
                className={selectedCategory === category.id 
                  ? "bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg hover:from-orange-600 hover:to-red-600" 
                  : "border-2 border-orange-200 hover:border-orange-300 hover:bg-orange-50 text-orange-700"
                }
              >
                {category.name}
              </Button>
            ))}
          </div>
        </div>

        {/* Enhanced Products Grid */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold text-gray-900">
              {selectedCategory 
                ? `${categories.find(c => c.id === selectedCategory)?.name} Products`
                : 'Featured Products'
              }
            </h2>
            <div className="text-sm text-orange-600 bg-orange-100 px-4 py-2 rounded-full border border-orange-200">
              {filteredProducts.length} products found
            </div>
          </div>
          
          {productsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="bg-white rounded-2xl shadow-lg p-6 animate-pulse border border-orange-100">
                  <div className="bg-orange-200 h-48 rounded-xl mb-4"></div>
                  <div className="bg-orange-200 h-4 rounded mb-2"></div>
                  <div className="bg-orange-200 h-4 rounded w-3/4"></div>
                </div>
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-2xl shadow-lg border border-orange-100">
              <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="w-10 h-10 text-orange-400" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">No products found</h3>
              <p className="text-gray-500 mb-6">Try adjusting your search or browse different categories.</p>
              <Button 
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory(null);
                }}
                className="bg-gradient-to-r from-orange-500 to-red-500 text-white hover:from-orange-600 hover:to-red-600"
              >
                Clear Filters
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <div key={product.id} className="transform hover:scale-105 transition-transform duration-300">
                  <ProductCard
                    product={product}
                    userType={userType}
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MarketplacePage;
