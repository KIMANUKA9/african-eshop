
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Store, ShoppingBag } from 'lucide-react';
import AuthModal from '@/components/auth/AuthModal';

interface UserTypeSelectorProps {
  onSelectUserType: (type: 'admin' | 'seller' | 'buyer') => void;
}

const UserTypeSelector = ({ onSelectUserType }: UserTypeSelectorProps) => {
  const [showAuthModal, setShowAuthModal] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            Welcome to Africa E-Shop Connect
          </h1>
          <p className="text-gray-600">
            Sign up or login to access our marketplace
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Admin Card */}
          <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-blue-500">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-red-600" />
              </div>
              <CardTitle>Admin</CardTitle>
              <CardDescription>Platform Administrator</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <ul className="text-sm text-gray-600 mb-6 space-y-2">
                <li>• Manage all users and sellers</li>
                <li>• Approve new sellers</li>
                <li>• Delete inappropriate content</li>
                <li>• View platform analytics</li>
                <li>• Monitor transactions</li>
              </ul>
              <Button 
                className="w-full"
                onClick={() => setShowAuthModal(true)}
              >
                Continue as Admin
              </Button>
            </CardContent>
          </Card>

          {/* Seller Card */}
          <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-blue-500">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Store className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle>Seller</CardTitle>
              <CardDescription>Vendor/Shop Owner</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <ul className="text-sm text-gray-600 mb-6 space-y-2">
                <li>• Create and manage your shop</li>
                <li>• Add and edit products</li>
                <li>• Track orders and sales</li>
                <li>• Receive payments via M-Pesa</li>
                <li>• Manage inventory</li>
              </ul>
              <Button 
                className="w-full"
                onClick={() => setShowAuthModal(true)}
              >
                Start Selling
              </Button>
            </CardContent>
          </Card>

          {/* Buyer Card */}
          <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-blue-500">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShoppingBag className="w-8 h-8 text-blue-600" />
              </div>
              <CardTitle>Buyer</CardTitle>
              <CardDescription>Customer/Shopper</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <ul className="text-sm text-gray-600 mb-6 space-y-2">
                <li>• Browse thousands of products</li>
                <li>• Search and filter items</li>
                <li>• Add to cart and checkout</li>
                <li>• Pay with M-Pesa, Tigo Pesa</li>
                <li>• Track your orders</li>
              </ul>
              <Button 
                className="w-full"
                onClick={() => setShowAuthModal(true)}
              >
                Start Shopping
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-8">
          <p className="text-sm text-gray-500">
            Create your account and join our growing marketplace community!
          </p>
        </div>
      </div>

      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
      />
    </div>
  );
};

export default UserTypeSelector;
