
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Menu } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import Logo from '@/components/common/Logo';
import Navigation from '@/components/layout/Navigation';
import UserActions from '@/components/user/UserActions';

interface HeaderProps {
  userType?: 'admin' | 'seller' | 'buyer' | null;
  cartItemsCount?: number;
}

const Header = ({ userType = null, cartItemsCount = 0 }: HeaderProps) => {
  return (
    <header className="bg-white shadow-md border-b border-orange-100 sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Logo />

          {/* Desktop Navigation */}
          <Navigation className="hidden md:flex items-center space-x-6" />

          {/* Right Side Actions */}
          <div className="flex items-center space-x-4">
            <UserActions userType={userType} cartItemsCount={cartItemsCount} />

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm" className="md:hidden border-orange-200 hover:bg-orange-50">
                  <Menu className="w-4 h-4 text-orange-600" />
                </Button>
              </SheetTrigger>
              <SheetContent className="bg-white">
                <div className="flex flex-col space-y-4 mt-8">
                  <Navigation className="flex flex-col space-y-4" />
                  {!userType && (
                    <>
                      <Button variant="outline" className="w-full border-orange-200 text-orange-700 hover:bg-orange-50">Login</Button>
                      <Button className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white hover:from-orange-600 hover:to-red-600">Sign Up</Button>
                    </>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
