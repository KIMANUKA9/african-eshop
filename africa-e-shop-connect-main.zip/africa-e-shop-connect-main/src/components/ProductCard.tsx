
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, Heart, Edit, Trash2, MessageCircle, MapPin } from 'lucide-react';
import ProductImage from '@/components/common/ProductImage';
import { useAddToCart } from '@/hooks/useProducts';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Product } from '@/hooks/useProducts';
import { useCreateConversation } from '@/hooks/useMessages';
import { useNavigate } from 'react-router-dom';

interface ProductCardProps {
  product: Product;
  userType?: 'admin' | 'seller' | 'buyer' | null;
  onEdit?: (productId: string) => void;
  onDelete?: (productId: string) => void;
}

const ProductCard = ({ 
  product, 
  userType = null, 
  onEdit, 
  onDelete 
}: ProductCardProps) => {
  const { user } = useAuth();
  const addToCart = useAddToCart();
  const createConversation = useCreateConversation();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleAddToCart = async () => {
    if (!user) {
      toast({
        title: 'Login Required',
        description: 'Please login to add items to cart',
        variant: 'destructive',
      });
      return;
    }

    try {
      await addToCart.mutateAsync({ productId: product.id });
      toast({
        title: 'Added to Cart',
        description: `${product.name} has been added to your cart`,
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to add item to cart',
        variant: 'destructive',
      });
    }
  };

  const handleContactSeller = async () => {
    if (!user) {
      toast({
        title: 'Login Required',
        description: 'Please login to contact sellers',
        variant: 'destructive',
      });
      return;
    }

    if (!product.shops?.seller_id) {
      toast({
        title: 'Error',
        description: 'Unable to contact seller',
        variant: 'destructive',
      });
      return;
    }

    try {
      await createConversation.mutateAsync({
        sellerId: product.shops.seller_id,
        productId: product.id,
      });
      navigate('/messages');
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to start conversation',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      {/* Product Image */}
      <div className="relative">
        <ProductImage 
          src={product.image_url || ''} 
          alt={product.name}
          className="w-full h-48 object-cover cursor-pointer"
          onClick={() => window.location.href = `/product/${product.id}`}
        />
        {product.stock === 0 && (
          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <Badge variant="destructive">Out of Stock</Badge>
          </div>
        )}
        {(userType === 'buyer' || !userType) && (
          <Button 
            variant="outline" 
            size="sm" 
            className="absolute top-2 right-2 bg-white"
          >
            <Heart className="w-4 h-4" />
          </Button>
        )}
      </div>

      {/* Product Info */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 
            className="font-semibold text-lg text-gray-800 line-clamp-2 cursor-pointer hover:text-blue-600"
            onClick={() => window.location.href = `/product/${product.id}`}
          >
            {product.name}
          </h3>
          <Badge variant="outline" className="ml-2 text-xs">
            {product.categories?.name || 'Uncategorized'}
          </Badge>
        </div>

        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
          {product.description}
        </p>

        {/* Location Info */}
        {(product as any).location_name && (
          <div className="flex items-center text-sm text-gray-500 mb-2">
            <MapPin className="w-3 h-3 mr-1" />
            <span>{(product as any).location_name}</span>
          </div>
        )}

        <div className="flex items-center justify-between mb-3">
          <span className="text-2xl font-bold text-blue-600">
            TSh {product.price.toLocaleString()}
          </span>
          <span className="text-sm text-gray-500">
            Stock: {product.stock}
          </span>
        </div>

        <div className="text-sm text-gray-500 mb-4">
          Sold by: <span className="font-medium">{product.shops?.name || 'Unknown'}</span>
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-2">
          {/* Buyer Actions */}
          {(userType === 'buyer' || !userType) && (
            <>
              <Button 
                className="flex-1" 
                onClick={handleAddToCart}
                disabled={product.stock === 0 || addToCart.isPending}
              >
                <ShoppingCart className="w-4 h-4 mr-2" />
                {addToCart.isPending ? 'Adding...' : 'Add to Cart'}
              </Button>
              <Button 
                variant="outline"
                size="sm"
                onClick={handleContactSeller}
                disabled={createConversation.isPending}
              >
                <MessageCircle className="w-4 h-4" />
              </Button>
            </>
          )}

          {/* Seller Actions */}
          {userType === 'seller' && (
            <>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => onEdit?.(product.id)}
              >
                <Edit className="w-4 h-4" />
              </Button>
              <Button 
                variant="destructive" 
                size="sm"
                onClick={() => onDelete?.(product.id)}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </>
          )}

          {/* Admin Actions */}
          {userType === 'admin' && (
            <>
              <Button 
                variant="outline" 
                size="sm" 
                className="flex-1"
                onClick={() => window.location.href = `/product/${product.id}`}
              >
                View Details
              </Button>
              <Button 
                variant="destructive" 
                size="sm"
                onClick={() => onDelete?.(product.id)}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
