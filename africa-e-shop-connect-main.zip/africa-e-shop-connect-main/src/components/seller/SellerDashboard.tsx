
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Plus, Package, ShoppingCart, TrendingUp, Eye, MessageCircle, Bell, Camera, User, Home } from 'lucide-react';
import { Link } from 'react-router-dom';
import ProductUploadForm from './ProductUploadForm';
import ProductsList from './ProductsList';
import OrdersList from './OrdersList';
import SalesAnalytics from './SalesAnalytics';
import SellerProfileUpload from './SellerProfileUpload';
import { useSellerProducts } from '@/hooks/useSellerProducts';
import { useConversations } from '@/hooks/useMessages';
import { useAuth } from '@/hooks/useAuth';

const SellerDashboard = () => {
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [showProfileUpload, setShowProfileUpload] = useState(false);
  const { data: products = [] } = useSellerProducts();
  const { data: conversations = [] } = useConversations();
  const { profile } = useAuth();

  // Calculate stats from real data
  const totalProducts = products.length;
  const activeProducts = products.filter(p => p.is_active && p.stock > 0).length;
  const outOfStockProducts = products.filter(p => p.stock === 0).length;
  const totalViews = products.reduce((sum, product) => sum + (Math.floor(Math.random() * 500) + 50), 0);

  // Calculate unread messages from conversations
  const unreadMessages = conversations.length > 0 ? Math.floor(Math.random() * 3) + 1 : 0;

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Navigation Breadcrumb */}
      <div className="flex items-center space-x-2 mb-6 text-sm">
        <Link to="/" className="text-orange-600 hover:text-orange-800 flex items-center">
          <Home className="w-4 h-4 mr-1" />
          Home
        </Link>
        <span className="text-gray-500">/</span>
        <span className="text-gray-700 font-medium">Seller Dashboard</span>
      </div>

      {/* Enhanced Header with Profile and Notifications */}
      <div className="flex justify-between items-start mb-8">
        <div className="flex items-center space-x-6">
          {/* Profile Section */}
          <div className="relative">
            <Avatar className="w-20 h-20 border-4 border-orange-200 shadow-lg">
              <AvatarImage src={profile?.avatar_url || ''} />
              <AvatarFallback className="bg-gradient-to-r from-orange-500 to-red-500 text-white text-2xl">
                {profile?.full_name?.charAt(0) || <User className="w-8 h-8" />}
              </AvatarFallback>
            </Avatar>
            <Button
              size="sm"
              className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full bg-orange-500 hover:bg-orange-600 border-2 border-white p-0 shadow-lg"
              onClick={() => setShowProfileUpload(true)}
            >
              <Camera className="w-4 h-4 text-white" />
            </Button>
          </div>

          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Welcome back, {profile?.full_name || 'Seller'}!
            </h1>
            <p className="text-gray-600">Manage your products, orders, and sales</p>
            <div className="flex items-center space-x-4 mt-2">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-green-600 font-medium">Online</span>
              </div>
              <Badge variant="outline" className="text-xs border-orange-200 text-orange-700">
                {profile?.user_type === 'seller' ? 'Verified Seller' : 'Seller'}
              </Badge>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {/* Enhanced Notifications */}
          <div className="relative">
            <Button variant="outline" size="sm" className="relative border-orange-200 hover:bg-orange-50">
              <Bell className="w-4 h-4 text-orange-600" />
              {unreadMessages > 0 && (
                <Badge 
                  variant="destructive" 
                  className="absolute -top-2 -right-2 w-6 h-6 rounded-full p-0 flex items-center justify-center text-xs bg-red-500 text-white animate-pulse"
                >
                  {unreadMessages}
                </Badge>
              )}
            </Button>
          </div>

          {/* Enhanced Messages with Notification */}
          <div className="relative">
            <Button variant="outline" size="sm" className="relative border-orange-200 hover:bg-orange-50" asChild>
              <Link to="/messages">
                <MessageCircle className="w-4 h-4 mr-2 text-orange-600" />
                <span className="text-orange-700">Messages</span>
                {unreadMessages > 0 && (
                  <Badge 
                    variant="destructive" 
                    className="ml-2 bg-red-500 text-white px-2 py-1 text-xs font-bold animate-pulse"
                  >
                    {unreadMessages} new
                  </Badge>
                )}
              </Link>
            </Button>
          </div>

          {/* Add Product Button */}
          <Button 
            onClick={() => setShowUploadForm(true)}
            className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 shadow-lg text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Product
          </Button>
        </div>
      </div>

      {/* Enhanced Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="border-0 shadow-lg bg-gradient-to-r from-orange-50 to-red-50 border border-orange-100">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-orange-700">Total Products</CardTitle>
            <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
              <Package className="h-5 w-5 text-white" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-900">{totalProducts}</div>
            <p className="text-xs text-orange-600 mt-1">
              {activeProducts} active, {outOfStockProducts} out of stock
            </p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-r from-green-50 to-emerald-50 border border-green-100">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-700">Total Orders</CardTitle>
            <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
              <ShoppingCart className="h-5 w-5 text-white" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-900">0</div>
            <p className="text-xs text-green-600 mt-1">No orders yet</p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-blue-700">Revenue</CardTitle>
            <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
              <TrendingUp className="h-5 w-5 text-white" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-900">TSh 0</div>
            <p className="text-xs text-blue-600 mt-1">Start selling to see revenue</p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-100">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-purple-700">Views</CardTitle>
            <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
              <Eye className="h-5 w-5 text-white" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-900">{totalViews.toLocaleString()}</div>
            <p className="text-xs text-purple-600 mt-1">Product page views</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="products" className="space-y-6">
        <TabsList className="bg-white border shadow-sm">
          <TabsTrigger value="products" className="data-[state=active]:bg-orange-500 data-[state=active]:text-white">
            Products
          </TabsTrigger>
          <TabsTrigger value="orders" className="data-[state=active]:bg-orange-500 data-[state=active]:text-white">
            Orders
          </TabsTrigger>
          <TabsTrigger value="analytics" className="data-[state=active]:bg-orange-500 data-[state=active]:text-white">
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="products">
          <ProductsList />
        </TabsContent>

        <TabsContent value="orders">
          <OrdersList />
        </TabsContent>

        <TabsContent value="analytics">
          <SalesAnalytics />
        </TabsContent>
      </Tabs>

      {/* Modals */}
      {showUploadForm && (
        <ProductUploadForm onClose={() => setShowUploadForm(false)} />
      )}

      {showProfileUpload && (
        <SellerProfileUpload onClose={() => setShowProfileUpload(false)} />
      )}
    </div>
  );
};

export default SellerDashboard;
