
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { useCart } from '@/hooks/useCart';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import ProductImage from '@/components/common/ProductImage';
import { CreditCard, Truck, MapPin, Shield, CheckCircle } from 'lucide-react';

const CheckoutPage = () => {
  const { data: cartItems = [] } = useCart();
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [shippingAddress, setShippingAddress] = useState({
    fullName: '',
    phone: '',
    address: '',
    city: '',
    region: '',
  });
  const [paymentMethod, setPaymentMethod] = useState('mpesa');

  const totalAmount = cartItems.reduce(
    (total, item) => total + (item.products.price * item.quantity),
    0
  );

  const shippingFee = 2000;
  const finalTotal = totalAmount + shippingFee;

  const handlePlaceOrder = async () => {
    if (!user) {
      toast({
        title: 'Authentication Required',
        description: 'Please login to place an order',
        variant: 'destructive',
      });
      return;
    }

    if (!shippingAddress.fullName || !shippingAddress.phone || !shippingAddress.address) {
      toast({
        title: 'Missing Information',
        description: 'Please fill in all required shipping details',
        variant: 'destructive',
      });
      return;
    }

    setIsProcessing(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 2000));

      toast({
        title: 'Order Placed Successfully!',
        description: `Your order for TSh ${finalTotal.toLocaleString()} has been placed. You'll receive a confirmation shortly.`,
      });

      navigate('/marketplace');
    } catch (error) {
      toast({
        title: 'Order Failed',
        description: 'Something went wrong while placing your order. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
        <Header userType={profile?.user_type} />
        <div className="container mx-auto px-4 py-8">
          <Card className="max-w-md mx-auto shadow-xl">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="w-8 h-8 text-gray-400" />
              </div>
              <h2 className="text-2xl font-bold mb-4 text-gray-800">Your cart is empty</h2>
              <p className="text-gray-600 mb-6">Add some amazing products to your cart before checking out.</p>
              <Button 
                onClick={() => navigate('/marketplace')}
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
              >
                Continue Shopping
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <Header userType={profile?.user_type} />
      <div className="container mx-auto px-4 py-8">
        {/* Modern Header */}
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Complete Your Order</h1>
          <p className="text-gray-600 text-lg">You're just one step away from getting your amazing products!</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-7xl mx-auto">
          {/* Enhanced Form Section */}
          <div className="space-y-6">
            <Card className="shadow-xl border-0">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-t-lg">
                <CardTitle className="flex items-center text-xl">
                  <Truck className="w-6 h-6 mr-3 text-blue-600" />
                  Shipping Information
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="fullName" className="text-sm font-medium text-gray-700">Full Name *</Label>
                    <Input
                      id="fullName"
                      value={shippingAddress.fullName}
                      onChange={(e) => setShippingAddress(prev => ({ ...prev, fullName: e.target.value }))}
                      placeholder="John Doe"
                      className="mt-1 border-2 focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone" className="text-sm font-medium text-gray-700">Phone Number *</Label>
                    <Input
                      id="phone"
                      value={shippingAddress.phone}
                      onChange={(e) => setShippingAddress(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder="+255 123 456 789"
                      className="mt-1 border-2 focus:border-blue-500"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="address" className="text-sm font-medium text-gray-700">Address *</Label>
                  <Input
                    id="address"
                    value={shippingAddress.address}
                    onChange={(e) => setShippingAddress(prev => ({ ...prev, address: e.target.value }))}
                    placeholder="Street address"
                    className="mt-1 border-2 focus:border-blue-500"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="city" className="text-sm font-medium text-gray-700">City</Label>
                    <Input
                      id="city"
                      value={shippingAddress.city}
                      onChange={(e) => setShippingAddress(prev => ({ ...prev, city: e.target.value }))}
                      placeholder="Dar es Salaam"
                      className="mt-1 border-2 focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <Label htmlFor="region" className="text-sm font-medium text-gray-700">Region</Label>
                    <Input
                      id="region"
                      value={shippingAddress.region}
                      onChange={(e) => setShippingAddress(prev => ({ ...prev, region: e.target.value }))}
                      placeholder="Dar es Salaam"
                      className="mt-1 border-2 focus:border-blue-500"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-xl border-0">
              <CardHeader className="bg-gradient-to-r from-green-50 to-blue-50 rounded-t-lg">
                <CardTitle className="flex items-center text-xl">
                  <CreditCard className="w-6 h-6 mr-3 text-green-600" />
                  Payment Method
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                  <SelectTrigger className="border-2 focus:border-green-500">
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mpesa">
                      <div className="flex items-center space-x-3">
                        <div className="bg-red-600 text-white px-3 py-1 rounded text-sm font-bold">M-PESA</div>
                        <span>Mobile Money</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="halotel">
                      <div className="flex items-center space-x-3">
                        <div className="bg-white border border-gray-200 text-orange-500 px-3 py-1 rounded text-sm font-bold">Halotel</div>
                        <span>Mobile Money</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="mixx">
                      <div className="flex items-center space-x-3">
                        <div className="bg-blue-600 text-yellow-400 px-3 py-1 rounded text-sm font-bold">Mixx by yas</div>
                        <span>Mobile Money</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="cash">
                      <div className="flex items-center space-x-3">
                        <div className="bg-gray-600 text-white px-3 py-1 rounded text-sm font-bold">Cash</div>
                        <span>Cash on Delivery</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
                
                <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center space-x-2 text-green-700">
                    <Shield className="w-5 h-5" />
                    <span className="text-sm font-medium">Your payment is secured with end-to-end encryption</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Enhanced Order Summary */}
          <div>
            <Card className="shadow-xl border-0 sticky top-8">
              <CardHeader className="bg-gradient-to-r from-orange-50 to-red-50 rounded-t-lg">
                <CardTitle className="text-xl">Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div className="max-h-80 overflow-y-auto space-y-4">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex gap-4 p-3 bg-gray-50 rounded-lg">
                      <ProductImage
                        src={item.products.image_url || ''}
                        alt={item.products.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold text-sm text-gray-900">{item.products.name}</h4>
                        <p className="text-xs text-gray-500">{item.products.shops?.name}</p>
                        <div className="flex justify-between items-center mt-2">
                          <span className="text-sm text-gray-600">Qty: {item.quantity}</span>
                          <span className="font-bold text-blue-600">
                            TSh {(item.products.price * item.quantity).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <div className="flex justify-between text-gray-700">
                    <span>Subtotal:</span>
                    <span className="font-medium">TSh {totalAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-gray-700">
                    <span>Shipping:</span>
                    <span className="font-medium">TSh {shippingFee.toLocaleString()}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-bold text-xl">
                    <span className="text-gray-900">Total:</span>
                    <span className="bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
                      TSh {finalTotal.toLocaleString()}
                    </span>
                  </div>
                </div>

                <Button 
                  className="w-full mt-6 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-bold py-4 text-lg shadow-lg" 
                  onClick={handlePlaceOrder}
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Processing...</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-5 h-5" />
                      <span>Place Order - TSh {finalTotal.toLocaleString()}</span>
                    </div>
                  )}
                </Button>

                <div className="text-center mt-4">
                  <p className="text-xs text-gray-500">
                    By placing this order, you agree to our Terms of Service and Privacy Policy
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
