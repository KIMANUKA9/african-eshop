
import React from 'react';

const Logo = () => {
  return (
    <div className="flex items-center space-x-2">
      <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
        <span className="text-white font-bold text-lg">A</span>
      </div>
      <h1 className="text-xl font-bold text-gray-800">Africa E-Shop</h1>
    </div>
  );
};

export default Logo;
