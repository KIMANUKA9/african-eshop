
import React, { useState } from 'react';
import { Images } from 'lucide-react';

interface ProductImageProps {
  src: string;
  alt: string;
  className?: string;
  onClick?: () => void;
}

const ProductImage = ({ src, alt, className = "w-full h-48 object-cover", onClick }: ProductImageProps) => {
  const [imageError, setImageError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const handleImageLoad = () => {
    setIsLoading(false);
    setImageError(false);
  };

  const handleImageError = () => {
    console.error('Failed to load image:', src);
    setImageError(true);
    setIsLoading(false);
  };

  // Check if src is a valid image URL or file
  const isValidImageSrc = src && src.trim() !== '' && src !== 'null' && src !== 'undefined';

  if (!isValidImageSrc || imageError) {
    return (
      <div 
        className={`${className} bg-muted border border-border flex items-center justify-center cursor-pointer hover:bg-muted/80 transition-colors rounded-lg`} 
        onClick={onClick}
      >
        <div className="text-center">
          <Images className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
          <p className="text-xs text-muted-foreground">No Image</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative rounded-lg overflow-hidden">
      {isLoading && (
        <div className={`${className} bg-muted animate-pulse flex items-center justify-center absolute inset-0 z-10 rounded-lg`}>
          <Images className="w-12 h-12 text-muted-foreground" />
        </div>
      )}
      <img
        src={src}
        alt={alt}
        className={`${className} ${isLoading ? 'opacity-0' : 'opacity-100'} transition-opacity duration-300 cursor-pointer hover:scale-105 transition-transform rounded-lg border border-border`}
        onLoad={handleImageLoad}
        onError={handleImageError}
        onClick={onClick}
        loading="lazy"
      />
    </div>
  );
};

export default ProductImage;
