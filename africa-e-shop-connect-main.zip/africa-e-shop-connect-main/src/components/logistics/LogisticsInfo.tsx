
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Truck, Clock, Phone } from 'lucide-react';

interface LogisticsInfoProps {
  product: {
    id: string;
    name: string;
    shops?: {
      name: string;
      seller_id: string;
    };
  };
}

const LogisticsInfo = ({ product }: LogisticsInfoProps) => {
  // Mock logistics data - in real app this would come from the database
  const logisticsInfo = {
    seller_location: {
      city: 'Dar es Salaam',
      region: 'Dar es Salaam',
      address: 'Kariakoo Market, Shop 45'
    },
    delivery_options: [
      {
        method: 'Standard Delivery',
        duration: '2-3 days',
        cost: 'TSh 5,000',
        description: 'Regular delivery within city'
      },
      {
        method: 'Express Delivery',
        duration: '24 hours',
        cost: 'TSh 15,000',
        description: 'Fast delivery service'
      },
      {
        method: 'Pickup',
        duration: 'Same day',
        cost: 'Free',
        description: 'Collect from seller location'
      }
    ],
    contact_info: {
      phone: '+255 123 456 789',
      whatsapp: '+255 123 456 789',
      business_hours: '8:00 AM - 6:00 PM'
    }
  };

  return (
    <div className="space-y-4">
      {/* Seller Location */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <MapPin className="w-5 h-5" />
            <span>Seller Location</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p className="font-medium">{product.shops?.name}</p>
            <p className="text-sm text-gray-600">{logisticsInfo.seller_location.address}</p>
            <p className="text-sm text-gray-600">
              {logisticsInfo.seller_location.city}, {logisticsInfo.seller_location.region}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Delivery Options */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Truck className="w-5 h-5" />
            <span>Delivery Options</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {logisticsInfo.delivery_options.map((option, index) => (
              <div key={index} className="border rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">{option.method}</h4>
                  <Badge variant="outline">{option.cost}</Badge>
                </div>
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{option.duration}</span>
                  </div>
                </div>
                <p className="text-sm text-gray-500 mt-1">{option.description}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Contact Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Phone className="w-5 h-5" />
            <span>Contact Seller</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Phone:</span>
              <span className="font-medium">{logisticsInfo.contact_info.phone}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">WhatsApp:</span>
              <span className="font-medium">{logisticsInfo.contact_info.whatsapp}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Business Hours:</span>
              <span className="font-medium">{logisticsInfo.contact_info.business_hours}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LogisticsInfo;
