
import React, { useState } from 'react';
import Header from '@/components/Header';
import MessagesList from './MessagesList';
import ChatWindow from './ChatWindow';
import { useAuth } from '@/hooks/useAuth';

const MessagesPage = () => {
  const { profile } = useAuth();
  const [selectedConversation, setSelectedConversation] = useState<{
    id: string;
    recipientId: string;
    recipientName: string;
  } | null>(null);

  const handleSelectConversation = (conversationId: string, recipientId: string, recipientName: string) => {
    setSelectedConversation({ id: conversationId, recipientId, recipientName });
  };

  const handleBackToList = () => {
    setSelectedConversation(null);
  };

  if (!profile) {
    return <div>Please log in to access messages.</div>;
  }

  return (
    <div>
      <Header userType={profile.user_type} />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Messages</h1>
        
        <div className="max-w-4xl mx-auto">
          {selectedConversation ? (
            <ChatWindow
              conversationId={selectedConversation.id}
              recipientId={selectedConversation.recipientId}
              recipientName={selectedConversation.recipientName}
              onBack={handleBackToList}
            />
          ) : (
            <MessagesList onSelectConversation={handleSelectConversation} />
          )}
        </div>
      </div>
    </div>
  );
};

export default MessagesPage;
