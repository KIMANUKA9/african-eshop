
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, User } from 'lucide-react';
import { useConversations } from '@/hooks/useMessages';
import { useAuth } from '@/hooks/useAuth';

interface MessagesListProps {
  onSelectConversation: (conversationId: string, recipientId: string, recipientName: string, recipientAvatar?: string) => void;
}

const MessagesList = ({ onSelectConversation }: MessagesListProps) => {
  const { user } = useAuth();
  const { data: conversations = [], isLoading } = useConversations();

  if (isLoading) {
    return <div className="p-4">Loading conversations...</div>;
  }

  if (conversations.length === 0) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <div className="w-20 h-20 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <MessageCircle className="w-10 h-10 text-blue-500" />
          </div>
          <h3 className="text-xl font-semibold mb-3">No conversations yet</h3>
          <p className="text-gray-500 max-w-sm mx-auto">
            Start shopping and contact sellers to begin conversations!
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <MessageCircle className="w-5 h-5" />
          <span>Your Conversations</span>
          <Badge variant="secondary">{conversations.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="space-y-1">
          {conversations.map((conversation) => {
            const isUserBuyer = conversation.buyer_id === user?.id;
            const recipientId = isUserBuyer ? conversation.seller_id : conversation.buyer_id;
            const recipientProfile = isUserBuyer ? conversation.seller_profile : conversation.buyer_profile;
            const recipientName = recipientProfile?.full_name || (isUserBuyer ? 'Seller' : 'Buyer');
            const recipientAvatar = recipientProfile?.avatar_url;
            
            return (
              <Button
                key={conversation.id}
                variant="ghost"
                className="w-full justify-start p-4 h-auto hover:bg-gray-50 border-b border-gray-100 last:border-b-0"
                onClick={() => onSelectConversation(conversation.id, recipientId, recipientName, recipientAvatar)}
              >
                <div className="flex items-center space-x-3 w-full">
                  <div className="relative">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={recipientAvatar || ''} />
                      <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
                        {recipientName.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
                  </div>
                  <div className="flex-1 text-left min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="font-semibold text-gray-900 truncate">{recipientName}</p>
                      <p className="text-xs text-gray-500">
                        {conversation.last_message_at
                          ? new Date(conversation.last_message_at).toLocaleDateString()
                          : 'New'
                        }
                      </p>
                    </div>
                    <p className="text-sm text-gray-500 truncate">
                      {conversation.last_message_at
                        ? `Last message: ${new Date(conversation.last_message_at).toLocaleDateString()}`
                        : 'Start a conversation'
                      }
                    </p>
                    <div className="flex items-center mt-2">
                      <Badge variant="outline" className="text-xs">
                        {isUserBuyer ? 'Seller' : 'Customer'}
                      </Badge>
                    </div>
                  </div>
                </div>
              </Button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default MessagesList;
