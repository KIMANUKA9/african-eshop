
import React from 'react';
import { cn } from '@/lib/utils';

interface PaymentMethodCardProps {
  name: string;
  bgColor: string;
  textColor: string;
  className?: string;
}

const PaymentMethodCard = ({ name, bgColor, textColor, className }: PaymentMethodCardProps) => {
  return (
    <div 
      className={cn(
        "inline-flex items-center justify-center px-3 py-2 rounded-md text-sm font-bold shadow-sm border",
        bgColor,
        textColor,
        className
      )}
    >
      {name}
    </div>
  );
};

export const PaymentMethods = ({ className }: { className?: string }) => {
  return (
    <div className={cn("flex items-center gap-3 flex-wrap", className)}>
      <PaymentMethodCard 
        name="M-PESA" 
        bgColor="bg-red-600 hover:bg-red-700" 
        textColor="text-white" 
      />
      <PaymentMethodCard 
        name="Halotel" 
        bgColor="bg-white hover:bg-gray-50 border-gray-200" 
        textColor="text-orange-500" 
      />
      <PaymentMethodCard 
        name="Mixx by yas" 
        bgColor="bg-blue-600 hover:bg-blue-700" 
        textColor="text-yellow-400" 
      />
    </div>
  );
};

export { PaymentMethodCard };
