
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { User, ChevronDown } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useCart } from '@/hooks/useCart';
import AuthModal from '@/components/auth/AuthModal';
import CartSheet from '@/components/cart/CartSheet';
import { useNavigate } from 'react-router-dom';

interface UserActionsProps {
  userType?: 'admin' | 'seller' | 'buyer' | null;
  cartItemsCount?: number;
}

const UserActions = ({ userType = null }: UserActionsProps) => {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const { user, profile, signOut } = useAuth();
  const { data: cartItems = [] } = useCart();
  const navigate = useNavigate();

  const cartItemsCount = cartItems.reduce((total, item) => total + item.quantity, 0);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const handleViewProfile = () => {
    navigate('/profile');
  };

  return (
    <div className="flex items-center space-x-4">
      {/* Shopping Cart (for buyers and non-authenticated users) */}
      {(userType === 'buyer' || !userType) && (
        <CartSheet cartItemsCount={cartItemsCount} />
      )}

      {/* User Menu */}
      {user && profile ? (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm">
              <User className="w-4 h-4 mr-2" />
              {profile.user_type === 'admin' ? 'Admin' : 
               profile.user_type === 'seller' ? 'Seller' : 
               profile.full_name || 'Profile'}
              <ChevronDown className="w-4 h-4 ml-2" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48 bg-white">
            <DropdownMenuItem onClick={handleViewProfile}>
              View Profile
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleSignOut}>
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ) : (
        <div className="hidden md:flex space-x-2">
          <Button variant="outline" size="sm" onClick={() => setShowAuthModal(true)}>
            Login
          </Button>
          <Button size="sm" onClick={() => setShowAuthModal(true)}>
            Sign Up
          </Button>
        </div>
      )}

      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
      />
    </div>
  );
};

export default UserActions;
